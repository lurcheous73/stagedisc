#!/bin/bash
# Rebuild the bundled, PCM-only DVD-Audio authoring helper from its GPL source.
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
source_root="$root/ThirdParty/dvda-author"
shim="$source_root/stagedisc-shim"
build="${STAGEDISC_DVDA_BUILD_DIR:-$root/build/dvda-author-arm64}"
mkdir -p "$build/obj"
rm -f "$build/obj"/*.o
flags=(-arch arm64 -mmacosx-version-min=14.0 -std=gnu99 -O2 -g -D_GNU_SOURCE -DHAVE_core_BUILD=1
  -DWITHOUT_FLAC -DWITHOUT_libogg -DWITHOUT_sox -DVERSION='"2019-dev"' -DPACKAGE_NAME='"dvda-author"'
  -I"$shim" -I"$source_root/src/include" -I"$source_root/libutils/src/include"
  -I"$source_root/libutils/src/private" -I"$source_root/libfixwav/src/include" -I"$source_root")
for name in amg2 ats atsi2 audio auxiliary dvda-author file_input_parsing samg2 launch_manager command_line_parsing lexer ats2wav mlp_stub sound; do
  source="$source_root/src/$name.c"
  [[ -f "$shim/$name.c" ]] && source="$shim/$name.c"
  clang "${flags[@]}" -c "$source" -o "$build/obj/$name.o" >"$build/$name.log" 2>&1
done
for name in libc_utils winport; do
  source="$source_root/libutils/src/$name.c"
  [[ -f "$shim/$name.c" ]] && source="$shim/$name.c"
  clang "${flags[@]}" -c "$source" -o "$build/obj/libutils-$name.o" >"$build/libutils-$name.log" 2>&1
done
for name in checkData checkParameters fixwav_auxiliary manager readHeader repair; do
  clang "${flags[@]}" -c "$source_root/libfixwav/src/$name.c" -o "$build/obj/libfixwav-$name.o" >"$build/libfixwav-$name.log" 2>&1
done
clang -arch arm64 -mmacosx-version-min=14.0 -g -o "$build/dvda-author" "$build"/obj/*.o -lz -lm >"$build/link.log" 2>&1
xcrun dsymutil "$build/dvda-author" -o "$build/dvda-author.dSYM"
file "$build/dvda-author"
otool -L "$build/dvda-author"
echo "Binary: $build/dvda-author"
echo "Symbols: $build/dvda-author.dSYM"
