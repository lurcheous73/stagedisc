/* StageDisc PCM-only compatibility shim for dvda-author. GPL-3.0-or-later. */
#ifndef STAGEDISC_MLP_SHIM_H
#define STAGEDISC_MLP_SHIM_H
#include "structures.h"
#include "c_utils.h"
#include "auxiliary.h"
#include "mlplayout.h"
int decode_mlp_file(fileinfo_t *info, globalData *globals);
int encode_mlp_file(fileinfo_t *info, globalData *globals);
void transport_to_mlp(fileinfo_t *info, globalData *globals);
#endif
