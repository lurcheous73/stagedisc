/* StageDisc PCM-only compatibility shim for dvda-author. GPL-3.0-or-later. */
#include "mlp.h"
/* StageDisc authors PCM DVD-Audio only; legacy MLP support is unavailable. */
int decode_mlp_file(fileinfo_t *info, globalData *globals) { (void)info; (void)globals; return -1; }
int encode_mlp_file(fileinfo_t *info, globalData *globals) { (void)info; (void)globals; return -1; }
void transport_to_mlp(fileinfo_t *info, globalData *globals) { (void)info; (void)globals; }
