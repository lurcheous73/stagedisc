# StageDisc DVD-Audio helper source

This is the corresponding source for the `Resources/bin/dvda-author` arm64 macOS 14+ helper. The upstream snapshot is [`fabnicol/dvda-author`](https://github.com/fabnicol/dvda-author) commit `a4447b2036839317b1103a57c2ffcc72493f47bf`. The `src`, `libutils` and `libfixwav` directories are copied from that commit. Original copyright and licence notices remain in those files. The upstream `COPYING` and `libfixwav/COPYING` are included; they contain GNU GPL version 3. Individual source files contain GPL version 2 or later and GPL version 3 or later notices. The linked work is distributed under GPL version 3 or later.

`stagedisc-shim` contains the complete modified source used in this build:

- `audio.c`: declare `audio_close_merged` and pass its required `globals` argument.
- `ats2wav.c`: include the macOS signal header and pass pointers to `close_handles`.
- `libc_utils.c`: use a valid failure exit in the standalone code path.
- `mlp.h` and `mlp_stub.c`: replace obsolete FFmpeg MLP APIs with unavailable-operation stubs. StageDisc only authors uncompressed PCM DVD-Audio; MLP input/encoding is unsupported.

Build with Xcode Command Line Tools on Apple Silicon:

```sh
bash Tools/build-dvda-author.sh
```

The script uses the supplied source and shim, `clang`, system zlib and `dsymutil`. It emits `build/dvda-author-arm64/dvda-author` plus a matching dSYM. It does not need Autotools, Homebrew or FFmpeg. To choose an output directory, set `STAGEDISC_DVDA_BUILD_DIR` to an absolute path. The helper is a separate GPL executable launched by StageDisc; the StageDisc app code remains under its own MIT licence. Only PCM DVD-Audio output was tested.
